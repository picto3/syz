// comment
// 変数 データにつけるラベル
/*
  データ型
  文字列
  数値
  真偽値(true / false)
  オブジェクト
    -配列
    -関数
    -組み込みオブジェクト
  undefined 未定義
  null なにもない
*/
var msg = "hello";
var x = 10,
    y = 20;
console.log(msg);
console.log(x + y);
