#include <stdio.h>
#include <stdlib.h>

int main(void)
{
  char cmd[30] = "ls";
  int hoge;

  hoge = system(cmd);

  return 0;
}
